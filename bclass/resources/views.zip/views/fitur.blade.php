@extends('layouts.masterlayout')
@section('title','halaman fitur')
@section('content')
<h1>{{ $nama }}</h1>
<a href="/product"> produk kami</a>
@endsection